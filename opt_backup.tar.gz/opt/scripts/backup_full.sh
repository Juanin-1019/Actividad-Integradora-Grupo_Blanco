#!/bin/bash

# Función de ayuda
mostrar_ayuda() {
    echo "Uso: $0 [origen] [destino]"
    echo ""
    echo "Argumentos:"
    echo "  origen   - El directorio que se desea respaldar (ej. /var/log)"
    echo "  destino  - El directorio donde se guardará el backup (debe ser /backup_dir o subcarpeta)"
    echo ""
    echo "Opciones:"
    echo "  -help, --help, -h   Muestra esta ventana de ayuda."
    echo ""
    echo "Ejemplo:"
    echo "  $0 /var/log /backup_dir"
    exit 0
}

# Verificar si se solicita ayuda
if [[ "$1" == "-help" || "$1" == "--help" || "$1" == "-h" ]]; then
    mostrar_ayuda
fi

# Validar que se pasaron ambos argumentos
if [ -z "$1" ] || [ -z "$2" ]; then
    echo "Error: Faltan argumentos obligatorios."
    mostrar_ayuda
fi

ORIGEN=$1
DESTINO=$2
FECHA=$(date +%Y%m%d)

# 1. Validar que el origen exista y sea un directorio
if [ ! -d "$ORIGEN" ]; then
    echo "Error: El directorio de origen '$ORIGEN' no existe o no está disponible."
    exit 1
fi

# 2. Validar que el destino esté disponible y montado
# Limpiamos barras inclinadas para asegurar la coincidencia en la comprobación
if ! mountpoint -q "/backup_dir"; then
    echo "Error: La partición de destino '/backup_dir' no está montada o disponible."
    exit 1
fi

if [ ! -d "$DESTINO" ]; then
    echo "Error: El punto de destino específico '$DESTINO' no existe."
    exit 1
fi

# Obtener el nombre base del directorio de origen para el archivo (ej: de /var/log obtiene log)
NOMBRE_BASE=$(basename "$ORIGEN")
NOMBRE_ARCHIVO="${NOMBRE_BASE}_bkp_${FECHA}.tar.gz"

echo "Iniciando backup de $ORIGEN en $DESTINO/$NOMBRE_ARCHIVO..."

# Ejecutar el empaquetado y compresión
tar -czf "$DESTINO/$NOMBRE_ARCHIVO" -C "$(dirname "$ORIGEN")" "$NOMBRE_BASE" 2>/dev/null

# Verificar si el comando tar terminó exitosamente
if [ $? -eq 0 ]; then
    echo "¡Backup completado con éxito!"
else
    echo "Error: Ocurrió un problema al crear el archivo de respaldo."
    exit 1
fi