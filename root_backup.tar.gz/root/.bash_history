history
history -w
rm -f /root/.bash_history
journalctl --rotate
journalctl --vacuum-time=1s
apt clean
sync
poweroff
echo "deb http://deb.debian.org/debian bullseye main" > /etc/apt/sources.list
apt install nano
nano /etc/hostname
init 6
blslk
lsblk
apt update
apt upgrade
nano /etc/apt/sources.list
apt update
apt upgrade
apt full-upgrade
apt --purge autoremove
init 6
mkdir /mnt/usb
lsblk
mount /dev/sdc1 /mnt/usb
lsblk
ls 
cat /home
ls /home
ls
ls /
ls /home/home
cd /home/home
cd /
umount /mnt/usb
apt install openssh-server
systemctl enable ssh
systemctl start ssh
nano /etc/ssh/sshd_config
ssh-keygen -t clave_publica
ssh-keygen
mkdir -p ~/.ssh
touch ~/.shh/authorized_keys
touch ~/.ssh/authorized_keys
echo "/home/clave_publica.pub" >> ~/.ssh/authorized_keys
cd ~/.ssh
cd /authorized_keys
cat ~/.ssh/authorized_keys
ls
cd ~/.ssh/authorized_keys
/home/clave_publica.pub > ~/.ssh/authorized_keys
cd /
/home/clave_publica.pub > ~/.ssh/authorized_keys
nano /home/clave_publica
nano /home/clave_publica.pub
/home/clave_publica.pub > ~/.ssh/authorized_keys
/home/clave_publica.pub >> ~/.ssh/authorized_keys
cat /home/clave_publica.pub > ~/.ssh/authorized_keys
cat ~/.ssh/authorized_keys
systemctl restart ssh
apt install apache2 php libapache2-mod-php
systemctl enable apache2
systemctl start apache2
cp /home/index.php /var/www/html
cp /home/logo.png /var/www/html
systemctl restart apache2
ip a
a2enmod php*
restart
reboot
touch ~/.ssh/id_rsa
cat /home/clave_privada.txt > ~/.ssh/id_rsa
ls /home
ls /home/home
ls /
cat /clave_privada.txt > ~/.ssh/id_rsa
cat /home/clave_publica.pub
cat /clave_publica.pub
cat ~/.ssh/authorized_keys
eval "$(ssh-agent -s)"
ssh-add ~/.ssh/id_rsa
chmod 700 ~/.ssh
chmod 600 ~/.ssh/id_rsa
ssh-add ~/.ssh/id_rsa
init 6
ssh-add ~/.ssh/id_rsa
eval "$(ssh-agent -s)"
ssh-add ~/.ssh/id_rsa
systemctl restart ssh
apt install mariadb-server
systemctl enable mariadb
systemctl start mariadb
mysql_secure_installation
mysql -u root -p < /db.sql
nano /etc/network/interfaces
nano /etc/network/interfaces
systemctl restart mariadb
init 6
lsblk
fdisk /dev/sdc
lsblk
fdisk /dev/sdc
lsblk
mkfs -t ext4 /dev/sdc1
mkfs -t ext4 /dev/sdc2
mkdir /www_dir
mkdir /backup_dir
mount /dev/sdc1 /www_dir
mount /dev/sdc2 /backup_dir
lsblk
blkid /dev/sdc1
blkid /dev/sdc2
cp /etc/fstab /etc/fstab.bak
nano /etc/fstab
lsblk
init 6
lsblk
find / -name "000-default.conf"
find / -name "apache2"
find / -name "apache2.conf"
php -v
apt install php-mysql
ls cat
ls /
cp /index.php /www_dir
cp /logo.png /www_dir
ls /www_dir
nano /etc/apache2/sites-available/000-default.conf 
nano /etc/apache2/sites-available/000-default.conf 
systemctl reload apache2
chown -R $USER:$USER /var/www/html
chown -R $USER:$USER /www_dir
chown -R $USER:$USER /www_dir/index.php 
chown -R $USER:$USER /var/www/html/index.php 
systemctl reload apache2
chown www-data:www-data /var/www/html/index.php
chown www-data:www-data /www_dir/index.php 
chmod 644 /var/www/html/index.php 
chmod 644 /www_dir/index.php 
systemctl reload apache2
init 6
